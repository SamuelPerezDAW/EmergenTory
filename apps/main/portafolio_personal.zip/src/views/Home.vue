<script setup lang="ts">
import TarjetaProyecto from '../components/TarjetaProyecto.vue'
import TarjetaHabilidad from '../components/TarjetaHabilidad.vue'
import type { Proyecto } from '../interfaces/Proyecto'
import type { Habilidad } from '../interfaces/Habilidad'

import es from '../locales/es.json'

const proyectos = es.proyectos.cards as Proyecto[]
const habilidades = es.habilidades.cards as Habilidad[]
</script>

<template>
    <main class="min-h-screen bg-blue-900 text-white">
        <div class="max-w-4xl mx-auto px-6 py-10">

        <header class="mb-16">
            <p class="mt-2 text-white/70">
            Frontend Developer · Vue · Tailwind
            </p>
        </header>

        <section id="sobre-mi" class="mb-16">
            <h2 class="text-2xl font-semibold mb-6">Sobre mí</h2>
            
            <p class="text-white/70 mb-4">
                Soy estudiante de Desarrollo de Aplicaciones Web, abierto a trabajar con cualquier programa y siempre con ganas de aprender.
            </p>

            <ul class="list-disc list-inside space-y-2 text-white/70">
                <li>Busco explorar más el mundo de la programación, tanto en Python como en otros lenguajes, y profundizar más en Frontend.</li>
                <li>Trabajo muy bien en equipo y tengo una organización bastante buena.</li>
                <li>Soy aficionado a los videojuegos: me encanta jugarlos y crearlos.</li>
                <li>También tengo el curso de Desarrollo de Aplicaciones Multiplataforma, en el cual hice la FCT en Bulgaria programando una aplicación móvil.</li>
                <li>Hice la FCT en Alemania en el ciclo medio de sistemas informáticos y redes.</li>
            </ul>
            </section>

        <section id="proyectos" class="mb-16">
            <h2 class="text-2xl font-semibold">Proyectos</h2>
            <div class="mt-6 grid grid-cols-1 sm:grid-cols-2 gap-4">
            <TarjetaProyecto
                v-for="(p, i) in proyectos"
                :key="i"
                v-bind="p"
            />
            </div>
        </section>
        <section id="habilidades" class="mb-16">
            <h2 class="text-2xl font-semibold mb-6">Habilidades</h2>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <TarjetaHabilidad
                v-for="(h, i) in habilidades"
                :key="i"
                v-bind="h"
            />
            </div>
        </section>

        <section id="contacto" class="mb-16">
            <h2 class="text-2xl font-semibold">Contacto</h2>

            <div class="mt-6 rounded-xl border border-white/10 bg-white/5 p-6">
                <p class="text-white/70 max-w-prose">
                ¿Te interesa trabajar conmigo o tienes alguna pregunta?
                Escríbeme y te respondo lo antes posible.
                </p>

                <div class="mt-6 flex flex-col sm:flex-row gap-4">
                <!-- EMAIL -->
                <a
                    href="mailto:besaygg@gmail.com"
                    class="inline-flex items-center justify-center rounded-lg bg-white px-4 py-2 text-sm font-medium text-black hover:opacity-90 focus:outline-2 focus:outline-offset-2 focus:outline-white"
                >
                    Enviar email
                </a>

                <!-- GITHUB -->
                <a
                    href="https://github.com/B202XD"
                    target="_blank"
                    rel="noreferrer"
                    class="inline-flex items-center justify-center rounded-lg border border-white/15 px-4 py-2 text-sm text-white/80 hover:text-white hover:border-white/25"
                >
                    GitHub
                </a>
                </div>
            </div>
            </section>


        <footer class="text-sm text-white/50">
            © 2026 — Besay
        </footer>

        </div>
    </main>
</template>
